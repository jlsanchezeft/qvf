"use strict";define([],function(){return{qHyperCubeDef:{qDimensions:[],qMeasures:[],qInitialDataFetch:[{qWidth:6,qHeight:1500}]}}});
//# sourceMappingURL=lib/maps/initialProperties.js.map
